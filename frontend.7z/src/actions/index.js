import axios from 'axios';
import { AUTH_ERROR, AUTH_USER } from './types';
export const uploadFile = (formFields, callback) => async dispatch => {
    try {
        const response = await axios.post('http://localhost:8080/data/fileUpload', formFields)
        console.log(response);
        //dispatch({ type: AUTH_USER, payload: response.formFields.token });
        //localStorage.setItem('token', response.formFields.token);
        callback();
    } catch (ex) {
        dispatch({ type: AUTH_ERROR, payload: 'an error occured' });
    }
};
export const signIn = (formFields, callback) => async dispatch => {
    try {
        const response = await axios.post('http://localhost:9090/OnlineAssessmentSystem/login', formFields)
        console.log(response);
        dispatch({ type: AUTH_USER, payload: response.formFields.token });
        localStorage.setItem('token', response.formFields.token);
        callback();
    } catch (ex) {
        dispatch({ type: AUTH_ERROR, payload: 'an error occured' });
    }
};