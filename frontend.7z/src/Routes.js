import React, { Fragment } from "react";
import { Route } from "react-router-dom";
import Login from './components/auth/Login';
import signup from './components/auth/signup';
//import Products from './components/auth/products';
//import DefaultHeader from './components/DefaultHeader';
const Routes = () => {
    return ( 
        <Fragment >
        <Route path = "/"
        exact component = { Login }/>
         <Route path = "/Login"
        component = { Login }/> 
        <Route path = "/signup"
        component = { signup }/>
      {/*    < Route path = "/products"
        component = { Products }/>  */}
      
        </Fragment> 
    )
}
export default Routes;