import React from 'react';
import Header from './Header';

const App=(props)=>{
    return(
       
        <div className="ui container">
        <Header/>
        {props.children}
        </div>
        
      
    );
};
export default App;