import React from 'react';
import {connect} from 'react-redux';
export default WrappedComponent=>{
    class WithAuthintication extends React.Component{
        componentDidMount(){
            this.shouldNavigateAway();
        }
        componentDidUpdate(){

            this.shouldNavigateAway();
        }
        shouldNavigateAway(){
            if(!this.props.auth){
                this.props.history.push('');
            }
        }
        render(){
          return <WrappedComponent{...this.props}/>
        }
    }
    const mapStateToProps=state=>{
        return{
            auth:state.auth.authenticated
        }
    }
    return connect(mapStateToProps)(WithAuthintication)
}