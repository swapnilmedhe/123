import React from 'react';
import {Link} from 'react-router-dom';
//{ Card, CardBody, CardHeader, Dropdown, DropdownItem, DropdownMenu, DropdownToggle, Nav, NavItem, NavLink } from 'reactstrap';
class  Header extends React.Component{
    constructor(props) {
        super(props);
    
        this.toggle = this.toggle.bind(this);
        this.state = {
          dropdownOpen: [false, false],
        };
      }
    
      toggle(i) {
        const newArray = this.state.dropdownOpen.map((element, index) => {
          return (index === i ? !element : false);
        });
        this.setState({
          dropdownOpen: newArray,
        });
      }
      render(){
      return(
        <div>
       
         
            <i className="fa fa-align-justify"></i><strong>Online Assessment</strong>
         
       
          
           {/*    <Dropdown nav isOpen={this.state.dropdownOpen[1]} toggle={() => {this.toggle(1);}}>
                <DropdownToggle nav caret>
                  Dropdown
                </DropdownToggle>
                <DropdownMenu>
                  <DropdownItem header>Header</DropdownItem>
                  <DropdownItem disabled>Action</DropdownItem>
                  <DropdownItem>Another Action</DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem>Another Action</DropdownItem>
                </DropdownMenu>
              </Dropdown> */}
      
             
           
        <div>
          <nav className="navbar navbar-inverse  navbar navbar-expand navbar-dark bg-dark " >
            <div className="collapse navbar-collapse d-flex bd-highlight">
              <div className="navbar-nav p-2 flex-grow-1 bd-highlight">
           
             <Link className="nav-item nav-link" to="/">Home</Link>
              <Link className="nav-item nav-link" to="/products">Products</Link>
              <Link className="nav-item nav-link" to="/categories">Categories</Link>
              {/* <div className="navbar-nav float-right">
                <Link className="nav-item nav-link" to="/signout">Signout</Link>
              </div> */}
              <div className="navbar-nav float-right">
                <Link className="nav-item nav-link" to="/Login">Login</Link>
              </div>
              </div>
       
            </div>
          </nav>
        </div>
        
        
       
    </div>
    )
}
}
export default Header;