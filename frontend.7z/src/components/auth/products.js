import React from 'react';
//import requireAuth from '../../components/requireAuth';
class Products extends React.Component{
    render(){
        return(<div className="container-fluid "><h3 align="center">this is page for listing products!!</h3></div>)}
}
export default Products;