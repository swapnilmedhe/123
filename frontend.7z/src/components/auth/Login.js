import React from 'react';
import { Field, reduxForm } from 'redux-form';
import { connect } from 'react-redux';
import { compose } from 'redux';
import * as actions from '../../actions'
import { Link } from 'react-router-dom';
import './styles.css';

class LogIn extends React.Component {
    constructor(props) {
        super(props);
     this.state = {
            email: "",
            password: "",
            submitted: false,

            emailError: "",
            passwordError: "",
 }
        this.onSubmit = this.onSubmit.bind(this);
    }
    handleChange = event => {
        //  const {name,value}=event.target;
        //  let formErrors=this.state.formErrors;
        this.setState({
            [event.target.name]: event.target.value,
        })
    }
    validate = () => {
        let emailError = "";
        let passwordError = "";
        if (!this.state.email.includes("@")) {
            emailError = "invalid email";
        }
        if (!this.state.password.match(/^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&]).*$/)) {
            passwordError = "password should contain atleast one special character,one digit,one capital alphabet and length should be 8 characters long";
            // this.state.password.length<6 &&
        }
    
    if (emailError || passwordError) {
      this.setState({ emailError, passwordError });
      return false;
    }
        return true;
    };

    onSubmit = event => {
        event.preventDefault();

        const isValid = this.validate();
        if (isValid) {
            // alert('Your favorite flavor is: ' + this.state.value1);
            console.log(this.state);
            // clear form
        }
        const { email, password } = this.state;
        this.setState({ submitted: true });

        const data = { 'email': email, 'password': password };

        console.log(data);

        this.props.signIn({ data }, () => {
            this.props.history.push('/products');
        });
    }

 
    render() {

        const { handleSubmit } = this.props;
        //const { formErrors } = this.state;
        return (
            <div>
                <div className="card card_style">
                    <div className="card-body">
                        <h5 className="card-title row justify-content-center">Login </h5>
                        <form
                            onSubmit={this.onSubmit} novalidate>
                            <section className="container-fluid signin-form">
                                <section className="row justify-content-center">
                                    <section className="col-lg-3 col-sm-12 col-md-6">
                                        <div className="form-group">
                                            <input
                                                name="email" required
                                                className="form-control"
                                                placeholder="email"
                                                value={this.state.email}
                                                onChange={this.handleChange}
                                            />
                                            <div style={{ fontSize: 12, color: "red" }}>
                                                {this.state.emailError}
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <input
                                                type="password"
                                                className="form-control"
                                                name="password"
                                                placeholder="password"
                                                value={this.state.password}
                                                onChange={this.handleChange}
                                            />
                                            <div style={{ fontSize: 12, color: "red" }}>
                                                {this.state.passwordError}
                                            </div>
                                        </div>
                                        {/*   <fieldset className="form-group">
                     {/* //<div>
                                            {this.props.errorMessage}
                                        </div> */ }
                                        <button className="btn btn-primary btn-block" >Login</button>

                                        <Link to="/signup" className="btn btn-link btn-block">Click here to Signup</Link>

                                    </section>
                                </section>
                            </section>
                        </form>
                    </div>
                </div>
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        errorMessage: state.auth.errorMessage
    }
}
export default compose(
    connect(mapStateToProps, actions),
    reduxForm({ form: 'Login' })
)(LogIn);