import React from 'react';
import { Field,reduxForm } from 'redux-form';
import { connect } from 'react-redux';
import { compose } from 'redux';
//import { Dropdown, DropdownItem, DropdownMenu, DropdownToggle } from 'reactstrap';
import * as actions from '../../actions';

  
  class ValidationForm extends React.Component {
  constructor(props){
    super(props);
    this.state={
      formFields:{
      category: "",
    course:"",
  sub_course_topic:"",
  numberOfQuestions:"",
excelfile:""
  
   
    }
  }
  this.onSubmit = this.onSubmit.bind(this);
  }
    
  
  handleChange = event => {
     // const isCheckbox = event.target.type === "checkbox";
      this.setState({ [ event.target.name]: event.target.value,
    // clickGender:event.target.value,
    //role:event.target.value
      });
    
    }; 
    
     
  
    onSubmit = event => {
      event.preventDefault();
     
    const formFields=this.state.formFields; 

       this.setState({formFields:formFields});
       console.log(formFields);
      this.props.uploadFile(formFields, () => {
        this.props.history.push('/Login');
        console.log(formFields);
      })
    };
  
    render() {
      return (
          <div className="container fluid">
        <h5 className="card-title row justify-content-center">SignUp </h5>
        <form onSubmit={(this.onSubmit)}>
                <div className="messages" />
                <div className="controls">
                  <div className="row">
                    <div className="col-md-6">
                      <div className="form-group">
                        <fieldset className="form-group">
                          <label htmlFor="form_need"> Category *</label>

                          <Field
                            name="category"
                            className="form-control"
                            required="required"
                            component="select"
                          >
                            <option value="" disabled>
                              Select Category
                            </option>
                            <option value="technical">Technical</option>
                            <option value="verbal">Verbal</option>
                            <option value="aptitude">Aptitude</option>
                          </Field>
                        </fieldset>
                        <div className="help-block with-errors" />
                      </div>
                    </div>
                  </div>
                  
                  <div className="row">
                    <div className="col-md-6">
                      <div className="form-group">
                        <fieldset className="form-group">
                          <label htmlFor="form_need">Course *</label>

                          <Field
                            name="course"
                            className="form-control"
                            required="required"
                            component="select"
                          >
                            <option value="" disabled>
                             Select course
                            </option>
                            <option value="java">java</option>
                            <option value="dot_net">.Net</option>
                            <option value="react">React</option>
                          </Field>
                        </fieldset>
                        <div className="help-block with-errors" />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group">
                        <label htmlFor="form_need">Sub Course_Topic *</label>
                        <fieldset className="form-group">
                          <Field
                            name="sub_course_topic"
                            className="form-control"
                            required="required"
                            component="select"
                          >
                            <option value="" disabled>
                              Select Sub_Coubse_Topic
                            </option>
                            <option value="subtopic1">subtopic1</option>
                            <option value="subtopic2">subtopic2</option>
                            <option value="subtopic3">subtopic3</option>
                          </Field>
                        </fieldset>
                        <div className="help-block with-errors" />
                      </div>
                    </div>
                    <div className="col-md-3">
                      <div className="form-group">
                        <fieldset className="form-group">
                          <label htmlFor="form_need">
                            Number of questions *
                          </label>

                          <Field
                            className="form-control"
                            name="numberOfQuestions"
                            type="number"
                            placeholder="Number of questions"
                            component="input"
                            required="required"
                          />
                        </fieldset>

                        <div className="help-block with-errors" />
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-12 d-flex justify-content-center">
                      <fieldset className="form-group">
                        <label htmlFor="form_need">Upload Excel file *</label>

                        <input type="File" name="excelfile" />
                      </fieldset>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-12 ">
                      <input
                        type="submit"
                        className="btn btn-success btn-send"
                        value="Create Test"
                      />
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-12">
                      <p className="text-muted">
                        <strong>*</strong> These fields are required.
                      </p>
                    </div>
                  </div>
                </div>
              </form>
            </div>
         
      );
    }
  }
  

const mapStateToProps = state => {
    return {
        errorMessage: state.auth.errorMessage
    }
}
export default compose(
    connect(mapStateToProps, actions),
    reduxForm({ form: 'signup' })
)(ValidationForm);
// reduxForm({form :'signup'})(SignUp);