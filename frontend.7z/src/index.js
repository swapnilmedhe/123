import React from 'react';
import ReactDom from 'react-dom';
import { Provider } from 'react-redux';

import App from './components/app';
import { BrowserRouter as Router } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import Routes from './Routes';
import configureStore from './store';



const store = configureStore({
    auth:{authenticated:localStorage.getItem('token')}
});
ReactDom.render(
    <Provider store={store}>
        <Router>
            <App>
                <Routes />
            </App>
        </Router>
    </Provider>,
    document.getElementById("root")
);