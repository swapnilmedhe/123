import React from 'react';
import { reduxForm, Field } from 'redux-form';
import { connect } from 'react-redux';
import { compose } from 'redux';
import {DropdownButton,Dropdown,Jumbotron,Container,Row,Col,Table} from 'react-bootstrap';
import './App.css';

import "bootstrap/dist/css/bootstrap.min.css";



class FileUpload extends React.Component {
  onSubmit = (formProps) => {
    this.props.fileupload(formProps, () => {
      this.props.history.push('/products');
    });
  };

  render() {
    const { handleSubmit } = this.props;
    return (
      <section className="container-fluid signin-form">
        <section className="row justify-content-center">
          <section className="col-lg-3 col-sm-12 col-md-6">
            <div className="alert alert-light">Please use the form below to sign up. </div>
            <form onSubmit={handleSubmit(this.onSubmit)}>
              <fieldset className="form-group">
                <label>Email</label>
                <Field
                  className="form-control"
                  name="email"
                  type="text"
                  autoComplete="none"
                  component="input" />
              </fieldset>
              <fieldset className="form-group">
                <label>Password</label>
                <Field
                  className="form-control"
                  name="password"
                  type="password"
                  autoComplete="none"
                  component="input" />
              </fieldset>
              <div>
                {this.props.errorMessage}
              </div>
              <button className="btn btn-primary btn-block">Sign up</button>
            </form>
          </section>
        </section>
      </section>
    );
  }
}

const mapStateToProps = state => {
  return {
    errorMessage: state.auth.errorMessage
  };
};

export default compose(
  connect(mapStateToProps, actions),
  reduxForm({ form: 'signup' })
)(FileUpload);
