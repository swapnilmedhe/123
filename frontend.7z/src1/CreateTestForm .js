import React, { Component } from "react";
import { reduxForm, Field } from "redux-form";
import { connect } from "react-redux";
import { compose } from "redux";
//import * as actions from "../../actions/testActions";
//import ImportFromFileBodyComponent from "./ImportFromFileBodyComponent";

import "bootstrap/dist/css/bootstrap.min.css";
//import "./fonts.css";
//import "./custom.css";

class CreateTestForm extends Component {
  onSubmit = formProps => {
    console.log(formProps);
    this.props.createTest(formProps);
  };

  render() {
    const UploadFile = ({
      input: { value: omitValue, ...inputProps },
      meta: omitMeta,
      ...props
    }) => <input type="file" {...inputProps} {...props} />;

    const { handleSubmit } = this.props;
    return (
      <div>
        <div className="container">
          <div className="row">
            <div className="col-xl-8 offset-xl-2 py-5">
              <h1>Create Test</h1>

              {/* <p className="lead">
                This is a demo htmlFor our tutorial dedicated to crafting
                working Bootstrap contact form with PHP and AJAX background.
              </p> */}

              <form onSubmit={handleSubmit(this.onSubmit)}>
                <div className="messages" />
                <div className="controls">
                  <div className="row">
                    <div className="col-md-6">
                      <div className="form-group">
                        <fieldset className="form-group">
                          <label htmlFor="form_need"> Category *</label>

                          <Field
                            name="category"
                            className="form-control"
                            required="required"
                            component="select"
                          >
                            <option value="" disabled>
                              Select Category
                            </option>
                            <option value="technical">Technical</option>
                            <option value="verbal">Verbal</option>
                            <option value="aptitude">Aptitude</option>
                          </Field>
                        </fieldset>
                        <div className="help-block with-errors" />
                      </div>
                    </div>
                  </div>
                  
                  <div className="row">
                    <div className="col-md-6">
                      <div className="form-group">
                        <fieldset className="form-group">
                          <label htmlFor="form_need">Course *</label>

                          <Field
                            name="course"
                            className="form-control"
                            required="required"
                            component="select"
                          >
                            <option value="" disabled>
                             Select course
                            </option>
                            <option value="java">java</option>
                            <option value="dot_net">.Net</option>
                            <option value="react">React</option>
                          </Field>
                        </fieldset>
                        <div className="help-block with-errors" />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group">
                        <label htmlFor="form_need">Sub Course_Topic *</label>
                        <fieldset className="form-group">
                          <Field
                            name="sub_course_topic"
                            className="form-control"
                            required="required"
                            component="select"
                          >
                            <option value="" disabled>
                              Select Sub_Coubse_Topic
                            </option>
                            <option value="subtopic1">subtopic1</option>
                            <option value="subtopic2">subtopic2</option>
                            <option value="subtopic3">subtopic3</option>
                          </Field>
                        </fieldset>
                        <div className="help-block with-errors" />
                      </div>
                    </div>
                    <div className="col-md-3">
                      <div className="form-group">
                        <fieldset className="form-group">
                          <label htmlFor="form_need">
                            Number of questions *
                          </label>

                          <Field
                            className="form-control"
                            name="numberOfQuestions"
                            type="number"
                            placeholder="Number of questions"
                            component="input"
                            required="required"
                          />
                        </fieldset>

                        <div className="help-block with-errors" />
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-12 d-flex justify-content-center">
                      <fieldset className="form-group">
                        <label htmlFor="form_need">Upload Excel file *</label>

                        <Field component={UploadFile} name="excelfile" />
                      </fieldset>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-12 ">
                      <input
                        type="submit"
                        className="btn btn-success btn-send"
                        value="Create Test"
                      />
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-12">
                      <p className="text-muted">
                        <strong>*</strong> These fields are required.
                      </p>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    errorMessage: "state.auth.errorMessage"
  };
};

export default compose(
  // connect(
  //   mapStateToProps,null
  //  // actions
  // ),
  reduxForm({ form: "createtest" })
)(CreateTestForm);
